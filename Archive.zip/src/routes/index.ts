export * from "./default.routes";
export * from "./auth.routes";
export * from "./user.routes";
export * from "./post.routes";
export * from "./comment.routes";
