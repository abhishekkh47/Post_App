export const SALT_ROUNDS = 10;
export const POST_TYPE = {
  TEXT: 1,
  IMAGE: 2,
};
